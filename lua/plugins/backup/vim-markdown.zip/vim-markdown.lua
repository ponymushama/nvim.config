return {
  "preservim/vim-markdown",
  config = function()
    -- disable folding
    vim.g.vim_markdown_folding_disabled = 1
  end,
}
