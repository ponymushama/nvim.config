return {
  "laishulu/vim-macos-ime",
  config = function()
    -- default IME mode
    vim.g.macosime_cjk_ime = "com.sogou.inputmethod.sogou.pinyin" 
  end,
}
