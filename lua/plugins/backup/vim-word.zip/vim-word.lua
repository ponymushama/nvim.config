return {
  "jspringyc/vim-word",
}
